package com.finsol.movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieRatingsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
