package com.finsol.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieEurekaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieEurekaServiceApplication.class, args);
	}

}
